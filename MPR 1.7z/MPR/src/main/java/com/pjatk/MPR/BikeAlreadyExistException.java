package com.pjatk.MPR;

public class BikeAlreadyExistException extends RuntimeException{
}
