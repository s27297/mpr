package com.pjatk.MPR;

public class BikeNotFoundException extends RuntimeException {
}
